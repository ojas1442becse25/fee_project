import { Link } from 'react-router-dom'
import { Sparkles, ArrowUpRight } from 'lucide-react'
import './Footer.css'

function Footer() {
  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Features', path: '/features' },
    { name: 'Career Discovery', path: '/career-discovery' },
    { name: 'FAQ', path: '/faq' },
    { name: 'Contact', path: '/contact' },
  ]

  return (
    <footer className="footer" role="contentinfo">
      <div className="container">
        <div className="footer-content">
          {/* Logo and Tagline */}
          <div className="footer-brand">
            <Link to="/" className="footer-logo" aria-label="Avenza Home">
              <div className="footer-logo-icon-wrap">
                <Sparkles size={16} />
              </div>
              <span className="footer-logo-text">avenza</span>
              <span className="footer-logo-badge">AI</span>
            </Link>
            <p className="footer-tagline">
              Explore. Compare. Decide. Adapt.
            </p>
            <p className="footer-subtext">
              Empowering students and future leaders with AI-backed career navigation.
            </p>
          </div>

          {/* Navigation Links */}
          <nav className="footer-nav" aria-label="Footer navigation">
            <span className="footer-nav-title">Platform</span>
            <div className="footer-links-grid">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className="footer-link"
                >
                  <span>{link.name}</span>
                  <ArrowUpRight size={12} className="footer-link-arrow" />
                </Link>
              ))}
            </div>
          </nav>
        </div>

        {/* Bottom Bar */}
        <div className="footer-bottom">
          <p className="footer-copyright">
            © {new Date().getFullYear()} AVENZA Intelligence. Crafted with precision for career excellence.
          </p>
          <div className="footer-legal-links">
            <span className="footer-status-indicator">
              <span className="status-ping" />
              All Systems Operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
