import { useState, useEffect, useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform, useReducedMotion, AnimatePresence } from 'framer-motion'
import {
  Brain,
  Code2,
  Palette,
  Database,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  Layers,
  Activity
} from 'lucide-react'
import './HeroVisual.css'

const DOMAINS = [
  {
    id: 'ai',
    title: 'AI Systems Engineer',
    category: 'Artificial Intelligence',
    icon: Brain,
    match: 98.4,
    salary: '₹14 – 38 LPA',
    growth: '+42% YoY',
    demand: 'Critical Demand',
    skills: ['PyTorch', 'LLMs', 'Vector DBs', 'RAG'],
    badgeColor: '#38BDF8',
    roadmap: 'Foundations → Deep Learning → Agentic AI',
  },
  {
    id: 'dev',
    title: 'Cloud Systems Architect',
    category: 'Engineering & Cloud',
    icon: Code2,
    match: 95.2,
    salary: '₹12 – 32 LPA',
    growth: '+29% YoY',
    demand: 'Very High',
    skills: ['Distributed Systems', 'Kubernetes', 'Go', 'AWS'],
    badgeColor: '#818CF8',
    roadmap: 'Core CS → Microservices → Scale Architecture',
  },
  {
    id: 'data',
    title: 'Data & Decision Scientist',
    category: 'Data Science',
    icon: Database,
    match: 96.8,
    salary: '₹13 – 35 LPA',
    growth: '+35% YoY',
    demand: 'High Demand',
    skills: ['Statistical Modeling', 'MLOps', 'Python', 'SQL'],
    badgeColor: '#34D399',
    roadmap: 'Math & Stats → ML Pipelines → Executive Insights',
  },
  {
    id: 'design',
    title: 'Lead Product Designer',
    category: 'Design & UX',
    icon: Palette,
    match: 93.5,
    salary: '₹10 – 26 LPA',
    growth: '+22% YoY',
    demand: 'High Demand',
    skills: ['Design Systems', 'UX Research', 'Figma', 'Interaction'],
    badgeColor: '#C084FC',
    roadmap: 'Visual Craft → Behavioral Psychology → Strategy',
  },
]

function HeroVisual() {
  const shouldReduceMotion = useReducedMotion()
  const stageRef = useRef(null)
  const [activeDomainIndex, setActiveDomainIndex] = useState(0)
  const currentDomain = DOMAINS[activeDomainIndex]

  // Mouse tilt tracking
  const mouseX = useMotionValue(0)
  const mouseY = useMotionValue(0)

  // Spring physics for tilt - noticeable yet silky smooth
  const springConfig = { damping: 25, stiffness: 100 }
  const tiltX = useSpring(useTransform(mouseY, [-0.5, 0.5], [16, -16]), springConfig)
  const tiltY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-18, 18]), springConfig)

  // Glare position
  const glareX = useSpring(useTransform(mouseX, [-0.5, 0.5], [0, 100]), springConfig)
  const glareY = useSpring(useTransform(mouseY, [-0.5, 0.5], [0, 100]), springConfig)

  // Parallax layers
  const cardSpring = { damping: 22, stiffness: 140 }
  const parallaxX1 = useSpring(useTransform(mouseX, [-0.5, 0.5], [-22, 22]), cardSpring)
  const parallaxY1 = useSpring(useTransform(mouseY, [-0.5, 0.5], [-16, 16]), cardSpring)
  const parallaxX2 = useSpring(useTransform(mouseX, [-0.5, 0.5], [20, -20]), cardSpring)
  const parallaxY2 = useSpring(useTransform(mouseY, [-0.5, 0.5], [16, -16]), cardSpring)

  useEffect(() => {
    if (shouldReduceMotion) return

    const handleWindowMouseMove = (e) => {
      if (window.innerWidth < 960) return
      const normalizedX = (e.clientX / window.innerWidth) - 0.5
      const normalizedY = (e.clientY / window.innerHeight) - 0.5
      mouseX.set(normalizedX)
      mouseY.set(normalizedY)
    }

    const handleWindowMouseLeave = () => {
      mouseX.set(0)
      mouseY.set(0)
    }

    window.addEventListener('mousemove', handleWindowMouseMove, { passive: true })
    document.addEventListener('mouseleave', handleWindowMouseLeave)

    return () => {
      window.removeEventListener('mousemove', handleWindowMouseMove)
      document.removeEventListener('mouseleave', handleWindowMouseLeave)
    }
  }, [mouseX, mouseY, shouldReduceMotion])

  return (
    <div className="hero-3d-stage" ref={stageRef} aria-label="Interactive Career Intelligence Engine">
      {/* Volumetric background lights */}
      <div className="hero-3d-ambient-light light-blue" />
      <div className="hero-3d-ambient-light light-violet" />

      {/* 3D Perspective Canvas with real pointer response */}
      <motion.div
        className="hero-3d-canvas"
        style={
          shouldReduceMotion
            ? {}
            : {
                rotateX: tiltX,
                rotateY: tiltY,
                transformStyle: 'preserve-3d',
              }
        }
      >
        {/* Deep Backdrop Glow Matrix */}
        <div className="hero-matrix-backdrop" />
        <div className="hero-matrix-grid-pattern" />

        {/* ── FLOATING SATELLITE 1: Active Trajectory Badge (Top Right) ── */}
        <motion.div
          className="hero-floating-badge badge-top-right"
          style={shouldReduceMotion ? {} : { x: parallaxX1, y: parallaxY1 }}
          animate={shouldReduceMotion ? {} : { y: [0, -6, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
        >
          <div className="floating-badge-icon cyan-glow">
            <Sparkles size={16} />
          </div>
          <div className="floating-badge-content">
            <div className="badge-highlight-row">
              <span className="badge-title">AI Trajectory Engine</span>
              <span className="badge-tag-live">Active</span>
            </div>
            <span className="badge-subtext">50+ Verified Career Graphs</span>
          </div>
        </motion.div>

        {/* ── CENTRAL CONSOLE: Career Intelligence Core ── */}
        <div className="hero-core-console">
          {/* Dynamic Glare Sheen */}
          <motion.div
            className="console-glare-overlay"
            style={shouldReduceMotion ? {} : { opacity: 0.6, backgroundPosition: `${glareX}% ${glareY}%` }}
          />

          {/* Top Status Header */}
          <div className="console-status-bar">
            <div className="console-status-indicator">
              <span className="pulse-dot" />
              <span className="console-status-text">AVENZA NEURAL CORE</span>
            </div>
            <div className="console-model-badge">
              <Activity size={12} />
              <span>Real-Time Fit</span>
            </div>
          </div>

          {/* Interactive Domain Switcher Pill Tabs */}
          <div className="console-domain-tabs" role="tablist" aria-label="Select career discipline">
            {DOMAINS.map((domain, idx) => {
              const Icon = domain.icon
              const isActive = idx === activeDomainIndex
              return (
                <button
                  key={domain.id}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  className={`domain-tab-btn ${isActive ? 'active' : ''}`}
                  onClick={() => setActiveDomainIndex(idx)}
                >
                  <Icon size={13} />
                  <span>{domain.id.toUpperCase()}</span>
                </button>
              )
            })}
          </div>

          {/* Dynamic Career Intelligence Content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentDomain.id}
              className="console-main-body"
              initial={{ opacity: 0, y: 8, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -8, scale: 0.98 }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            >
              <div className="console-role-header">
                <div>
                  <span className="console-category-label">{currentDomain.category}</span>
                  <h3 className="console-role-title">{currentDomain.title}</h3>
                </div>
                <div className="console-match-score">
                  <div className="match-score-number">{currentDomain.match}%</div>
                  <div className="match-score-label">Fit Index</div>
                </div>
              </div>

              {/* Match Progress Bar */}
              <div className="console-meter-container">
                <div className="console-meter-bar">
                  <motion.div
                    className="console-meter-fill"
                    initial={{ width: 0 }}
                    animate={{ width: `${currentDomain.match}%` }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                  />
                </div>
                <div className="console-meter-labels">
                  <span>Match Confidence</span>
                  <span className="text-cyan-accent">Optimal Match</span>
                </div>
              </div>

              {/* Data Grid: Salary & Growth */}
              <div className="console-metrics-row">
                <div className="metric-box">
                  <span className="metric-box-label">Avg. Industry CTC</span>
                  <span className="metric-box-value">{currentDomain.salary}</span>
                </div>
                <div className="metric-box">
                  <span className="metric-box-label">Market Velocity</span>
                  <span className="metric-box-value highlight-growth">
                    <TrendingUp size={13} />
                    {currentDomain.growth}
                  </span>
                </div>
              </div>

              {/* Skills In Demand */}
              <div className="console-skills-section">
                <span className="skills-section-label">High-Impact Competencies:</span>
                <div className="console-skill-chips">
                  {currentDomain.skills.map((skill) => (
                    <span key={skill} className="skill-chip">
                      <CheckCircle2 size={12} className="chip-check" />
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Interactive Roadmap Step */}
              <div className="console-roadmap-preview">
                <div className="roadmap-preview-header">
                  <Layers size={13} />
                  <span>Curated Roadmap:</span>
                </div>
                <div className="roadmap-preview-text">{currentDomain.roadmap}</div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* ── FLOATING SATELLITE 2: Multi-Factor Alignment (Bottom Left) ── */}
        <motion.div
          className="hero-floating-badge badge-bottom-left"
          style={shouldReduceMotion ? {} : { x: parallaxX2, y: parallaxY2 }}
          animate={shouldReduceMotion ? {} : { y: [0, 6, 0] }}
          transition={{ duration: 4.8, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
        >
          <div className="floating-badge-icon purple-glow">
            <ShieldCheck size={16} />
          </div>
          <div className="floating-badge-content">
            <span className="badge-title">Zero Guesswork</span>
            <span className="badge-subtext">Multi-factor psychometric alignment</span>
          </div>
        </motion.div>
      </motion.div>
    </div>
  )
}

export default HeroVisual
